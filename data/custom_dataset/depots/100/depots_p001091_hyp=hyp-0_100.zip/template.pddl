(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate5 crate9)
	(on crate1 pallet3)
	(at pallet5 depot0)
	(on crate0 pallet5)
	(on crate9 pallet0)
	(at pallet3 depot0)
	(at crate3 distributor0)
	(clear pallet2)
	(at crate7 distributor1)
	(on crate3 crate2)
	(at crate4 distributor1)
	(clear crate1)
	(clear crate6)
	(available hoist0)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate7 pallet1)
	(at crate8 distributor0)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate0 depot0)
	(at crate2 distributor0)
	(at pallet4 distributor0)
	(clear crate4)
	(at crate1 depot0)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(on crate2 pallet4)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(at truck1 distributor1)
	(at hoist0 distributor1)
	(on crate6 crate0)
	(on crate8 crate3)
	(clear crate8)
	(on crate4 crate7)
	(at hoist2 distributor0)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)