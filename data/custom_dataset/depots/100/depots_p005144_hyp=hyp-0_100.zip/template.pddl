(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
)
(:init

	(on crate2 crate6)
	(at crate3 depot0)
	(available hoist0)
	(clear crate1)
	(on crate3 crate7)
	(available hoist1)
	(on crate0 crate4)
	(on crate4 crate2)
	(at crate2 distributor0)
	(at truck1 distributor0)
	(at hoist1 depot0)
	(at crate6 distributor0)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at truck0 depot0)
	(at crate1 distributor0)
	(clear crate3)
	(on crate7 pallet0)
	(on crate1 crate5)
	(at hoist0 distributor0)
	(at pallet0 depot0)
	(on crate6 pallet1)
	(on crate5 crate0)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)