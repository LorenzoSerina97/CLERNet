(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate0 pallet5)
	(at pallet4 depot0)
	(at crate3 depot0)
	(at crate6 distributor1)
	(clear crate0)
	(at crate7 distributor1)
	(on crate3 crate2)
	(at crate4 distributor1)
	(available hoist0)
	(on crate9 pallet2)
	(at hoist2 distributor1)
	(available hoist1)
	(available hoist2)
	(on crate7 pallet3)
	(on crate2 crate5)
	(at crate0 depot0)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(at crate9 distributor1)
	(at pallet1 distributor0)
	(on crate6 crate1)
	(on crate5 pallet4)
	(at crate5 depot0)
	(at hoist0 depot0)
	(at hoist1 distributor0)
	(clear crate3)
	(clear pallet0)
	(at truck1 depot0)
	(on crate1 crate4)
	(clear crate9)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate8 crate6)
	(clear crate8)
	(on crate4 crate7)
	(at pallet3 distributor1)
	(at crate8 distributor1)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)