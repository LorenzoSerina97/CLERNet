(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(at pallet3 depot0)
	(at crate3 depot0)
	(available hoist0)
	(at pallet4 distributor1)
	(clear crate5)
	(at pallet0 distributor1)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(on crate2 crate0)
	(on crate8 crate1)
	(at crate0 depot0)
	(at crate4 depot0)
	(on crate4 pallet2)
	(on crate3 pallet3)
	(on crate0 crate7)
	(at crate1 depot0)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at crate5 distributor1)
	(at crate6 distributor0)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(clear pallet5)
	(on crate5 pallet4)
	(at crate9 distributor0)
	(at truck1 distributor1)
	(on crate9 crate6)
	(at hoist0 distributor1)
	(clear pallet0)
	(clear crate3)
	(on crate1 crate4)
	(clear crate2)
	(clear crate9)
	(at crate2 depot0)
	(on crate7 crate8)
	(on crate6 pallet1)
	(at hoist2 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)