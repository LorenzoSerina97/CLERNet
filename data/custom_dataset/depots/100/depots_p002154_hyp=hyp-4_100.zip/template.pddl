(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate1 crate2)
	(at crate3 distributor0)
	(on crate4 pallet1)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(available hoist1)
	(on crate3 crate4)
	(available hoist2)
	(at hoist0 depot1)
	(at crate1 depot0)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(on crate2 pallet0)
	(at crate5 depot1)
	(at hoist1 distributor0)
	(at pallet2 depot1)
	(clear crate3)
	(at crate2 depot0)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(on crate0 pallet2)
	(on crate5 crate0)
	(at crate0 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)