(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet3 depot0)
	(on crate5 crate7)
	(at crate6 distributor1)
	(clear crate1)
	(available hoist0)
	(on crate6 crate3)
	(clear crate5)
	(at crate8 distributor0)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate9 crate8)
	(available hoist2)
	(at pallet2 depot0)
	(on crate2 crate0)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(at crate4 depot0)
	(at pallet4 distributor0)
	(clear crate4)
	(at crate1 depot0)
	(at hoist1 depot0)
	(on crate8 pallet5)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(on crate0 crate6)
	(on crate1 pallet2)
	(on crate4 pallet3)
	(at crate3 distributor1)
	(at hoist0 distributor1)
	(clear pallet0)
	(at truck1 depot0)
	(at crate7 distributor0)
	(clear crate2)
	(at crate0 distributor1)
	(on crate3 pallet1)
	(at truck0 distributor1)
	(clear pallet4)
	(on crate7 crate9)
	(at hoist2 distributor0)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)