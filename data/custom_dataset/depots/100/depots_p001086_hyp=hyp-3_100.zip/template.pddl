(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate0 pallet5)
	(on crate9 pallet0)
	(at crate7 distributor1)
	(on crate4 crate9)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(at pallet0 distributor1)
	(available hoist1)
	(available hoist2)
	(on crate8 crate0)
	(at crate2 distributor1)
	(at crate0 depot0)
	(on crate3 pallet3)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(at crate5 distributor1)
	(at crate6 distributor0)
	(at crate9 distributor1)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(on crate6 crate1)
	(at truck1 distributor1)
	(on crate5 pallet2)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(at crate3 distributor1)
	(at hoist0 distributor1)
	(on crate2 crate7)
	(clear crate3)
	(on crate7 crate5)
	(clear crate2)
	(on crate1 pallet1)
	(at hoist2 depot0)
	(clear pallet4)
	(clear crate8)
	(at pallet3 distributor1)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)