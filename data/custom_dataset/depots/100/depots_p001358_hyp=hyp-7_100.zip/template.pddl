(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate4 pallet5)
	(at hoist1 distributor1)
	(at crate3 distributor0)
	(at pallet4 depot0)
	(at crate6 distributor1)
	(on crate3 crate2)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(on crate0 pallet1)
	(available hoist1)
	(at pallet5 distributor0)
	(at crate8 distributor0)
	(on crate5 crate6)
	(on crate1 crate0)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate2 distributor0)
	(on crate8 pallet0)
	(at pallet3 distributor0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at pallet2 distributor1)
	(on crate9 crate7)
	(at crate5 distributor1)
	(at crate4 distributor0)
	(on crate6 pallet2)
	(at pallet1 distributor1)
	(clear crate3)
	(on crate2 pallet3)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate0 distributor1)
	(on crate7 pallet4)
	(at hoist2 depot0)
	(at truck0 distributor1)
	(clear crate8)
	(at crate9 depot0)
	(clear crate4)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)