(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		crate0 - Crate
		crate1 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
)
(:init

	(at pallet3 depot0)
	(clear pallet3)
	(clear pallet2)
	(clear crate0)
	(on crate0 pallet0)
	(available hoist0)
	(clear crate1)
	(at hoist2 distributor1)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet2 distributor0)
	(available hoist2)
	(available hoist3)
	(at truck1 distributor0)
	(at hoist0 depot0)
	(at hoist3 depot1)
	(at hoist1 distributor0)
	(on crate1 pallet1)
	(at pallet1 depot1)
	(at crate0 distributor1)
	(at truck0 distributor1)
	(at crate1 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)