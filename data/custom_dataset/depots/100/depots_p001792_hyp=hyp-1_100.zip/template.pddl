(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet4 depot0)
	(at crate6 distributor1)
	(clear crate0)
	(at crate7 distributor1)
	(on crate3 crate2)
	(on crate8 crate7)
	(on crate4 crate9)
	(available hoist0)
	(clear crate6)
	(at hoist2 distributor1)
	(at pallet2 distributor0)
	(available hoist1)
	(at pallet0 distributor1)
	(available hoist2)
	(on crate7 pallet3)
	(on crate2 crate5)
	(at crate2 distributor0)
	(at crate4 depot0)
	(at crate1 depot0)
	(at truck0 distributor0)
	(on crate1 pallet4)
	(on crate9 crate1)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at hoist1 distributor0)
	(on crate6 pallet5)
	(clear pallet0)
	(clear crate3)
	(on crate0 pallet2)
	(clear crate8)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(on crate5 pallet1)
	(at crate9 depot0)
	(clear crate4)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)