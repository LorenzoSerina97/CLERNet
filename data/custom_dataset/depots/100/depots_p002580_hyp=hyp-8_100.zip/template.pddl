(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet0 depot1)
	(on crate4 pallet1)
	(at truck0 depot1)
	(at crate3 depot0)
	(clear crate0)
	(on crate0 crate1)
	(on crate3 crate2)
	(available hoist0)
	(at pallet2 distributor0)
	(available hoist1)
	(available hoist2)
	(at hoist0 depot1)
	(on crate2 crate5)
	(at crate4 depot0)
	(on crate5 crate4)
	(at crate0 distributor0)
	(at crate5 depot0)
	(on crate1 pallet2)
	(at crate1 distributor0)
	(at hoist1 distributor0)
	(clear crate3)
	(clear pallet0)
	(at truck1 depot0)
	(at pallet1 depot0)
	(at crate2 depot0)
	(at hoist2 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)