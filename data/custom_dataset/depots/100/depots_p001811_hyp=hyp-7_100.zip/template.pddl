(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate5 crate9)
	(on crate2 crate1)
	(on crate9 pallet0)
	(at crate3 distributor0)
	(clear crate0)
	(at crate4 distributor1)
	(available hoist0)
	(at pallet4 distributor1)
	(clear crate5)
	(at crate8 distributor0)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet2 depot0)
	(on crate8 pallet3)
	(on crate0 crate7)
	(at pallet3 distributor0)
	(at crate1 depot0)
	(on crate1 crate6)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(on crate6 pallet2)
	(at crate6 depot0)
	(at crate5 depot0)
	(at truck1 distributor1)
	(at hoist1 distributor0)
	(at hoist0 distributor1)
	(clear crate3)
	(at crate7 distributor0)
	(clear crate2)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate7 pallet5)
	(at hoist2 depot0)
	(on crate3 pallet1)
	(at truck0 distributor1)
	(clear crate8)
	(at crate9 depot0)
	(on crate4 pallet4)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)