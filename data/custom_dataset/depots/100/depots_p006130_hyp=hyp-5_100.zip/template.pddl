(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate1 pallet3)
	(at truck0 depot2)
	(at pallet4 depot1)
	(at truck1 depot2)
	(available hoist0)
	(clear crate1)
	(at hoist2 distributor1)
	(available hoist1)
	(available hoist2)
	(on crate2 crate0)
	(at truck2 distributor1)
	(at hoist5 distributor2)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(available hoist3)
	(at pallet5 depot2)
	(at pallet3 distributor2)
	(at pallet2 distributor1)
	(available hoist4)
	(at crate1 distributor2)
	(clear pallet5)
	(at hoist3 depot1)
	(at hoist1 distributor0)
	(at hoist4 depot0)
	(clear pallet0)
	(at pallet1 depot0)
	(clear crate2)
	(at crate0 distributor1)
	(clear pallet4)
	(on crate0 pallet2)
	(at hoist0 depot2)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)