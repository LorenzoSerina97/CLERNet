(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet0 depot1)
	(on crate2 crate1)
	(at pallet5 distributor1)
	(clear pallet3)
	(clear pallet2)
	(clear crate0)
	(available hoist0)
	(at hoist5 depot1)
	(available hoist1)
	(at pallet1 distributor2)
	(available hoist2)
	(at pallet2 depot0)
	(at truck2 distributor1)
	(at crate2 distributor1)
	(at pallet4 distributor0)
	(available hoist3)
	(on crate0 crate2)
	(at hoist3 distributor1)
	(at crate1 distributor1)
	(available hoist4)
	(on crate1 pallet5)
	(at hoist4 distributor2)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at hoist1 distributor0)
	(at hoist2 depot2)
	(clear pallet0)
	(at crate0 distributor1)
	(at pallet3 depot2)
	(at truck0 distributor1)
	(clear pallet4)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)