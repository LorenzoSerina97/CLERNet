(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet4 depot0)
	(at crate3 depot0)
	(clear crate0)
	(at crate7 distributor1)
	(on crate9 crate4)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate3 pallet4)
	(available hoist2)
	(on crate7 pallet3)
	(on crate8 crate9)
	(on crate5 crate1)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(on crate2 crate8)
	(at crate0 depot0)
	(on crate4 pallet2)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate9 distributor1)
	(clear pallet5)
	(on crate1 pallet0)
	(at crate6 depot0)
	(at crate1 distributor0)
	(at pallet1 depot0)
	(clear crate2)
	(at hoist0 distributor0)
	(on crate6 pallet1)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(on crate0 crate3)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)