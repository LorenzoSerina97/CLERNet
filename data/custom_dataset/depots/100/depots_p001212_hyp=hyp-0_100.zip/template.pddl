(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate5 crate9)
	(at pallet3 depot0)
	(at pallet4 depot0)
	(at crate3 depot0)
	(at crate6 distributor1)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at hoist2 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet0 distributor0)
	(on crate4 pallet0)
	(on crate3 pallet3)
	(at crate1 depot0)
	(at truck0 distributor0)
	(on crate9 pallet5)
	(at hoist1 depot0)
	(at pallet2 distributor1)
	(clear crate7)
	(on crate0 crate5)
	(at crate8 depot0)
	(at crate0 distributor0)
	(on crate6 pallet2)
	(at crate9 distributor0)
	(at crate4 distributor0)
	(on crate1 crate3)
	(at truck1 depot0)
	(at crate7 distributor0)
	(at pallet1 depot0)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(on crate7 crate0)
	(on crate8 crate2)
	(clear pallet4)
	(clear crate8)
	(clear crate4)
	(at crate5 distributor0)
	(on crate2 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)