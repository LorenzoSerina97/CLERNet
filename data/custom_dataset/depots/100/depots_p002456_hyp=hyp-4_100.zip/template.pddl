(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate1 crate2)
	(at crate3 distributor0)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate3 pallet2)
	(at hoist0 depot1)
	(available hoist2)
	(clear crate4)
	(at crate1 depot0)
	(at hoist1 depot0)
	(on crate0 crate5)
	(at crate4 distributor0)
	(on crate2 pallet0)
	(at crate5 depot1)
	(at truck0 depot0)
	(at truck1 depot0)
	(on crate4 crate3)
	(at crate2 depot0)
	(at pallet1 depot1)
	(at pallet0 depot0)
	(on crate5 pallet1)
	(at hoist2 distributor0)
	(at crate0 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)