(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(clear pallet3)
	(at pallet4 depot0)
	(at crate3 depot0)
	(at crate6 distributor1)
	(clear crate0)
	(on crate4 crate8)
	(at crate4 distributor1)
	(clear crate1)
	(available hoist0)
	(at pallet2 distributor0)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at crate0 depot0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(clear crate7)
	(on crate2 pallet4)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(on crate5 pallet2)
	(on crate3 pallet0)
	(at hoist1 distributor0)
	(at hoist0 distributor1)
	(at crate7 distributor0)
	(on crate1 crate4)
	(clear crate2)
	(clear crate9)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate8 crate6)
	(on crate7 pallet5)
	(at hoist2 depot0)
	(on crate6 pallet1)
	(on crate9 crate5)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(on crate0 crate3)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)