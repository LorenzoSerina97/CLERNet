(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at hoist1 distributor1)
	(clear pallet2)
	(clear crate0)
	(at truck2 depot1)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(at hoist5 depot1)
	(available hoist1)
	(available hoist2)
	(available hoist3)
	(at pallet3 distributor2)
	(at hoist3 distributor0)
	(at hoist2 distributor2)
	(available hoist4)
	(at pallet2 depot2)
	(at pallet1 distributor0)
	(clear pallet5)
	(at truck1 distributor1)
	(at pallet5 depot1)
	(on crate0 pallet4)
	(at crate1 distributor0)
	(at hoist4 depot0)
	(clear pallet0)
	(on crate2 pallet3)
	(clear crate2)
	(at crate0 distributor1)
	(on crate1 pallet1)
	(at pallet0 depot0)
	(at crate2 distributor2)
	(at truck0 distributor1)
	(at hoist0 depot2)
	(available hoist5)
)
(:goal 
(and
<HYPOTHESIS>
))
)