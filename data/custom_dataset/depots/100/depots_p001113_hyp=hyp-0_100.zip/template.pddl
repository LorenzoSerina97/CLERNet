(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet4 depot0)
	(clear pallet2)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(at hoist2 distributor1)
	(available hoist1)
	(available hoist2)
	(on crate9 pallet1)
	(on crate0 crate9)
	(at pallet0 distributor0)
	(on crate1 crate8)
	(at crate0 depot0)
	(at crate4 depot0)
	(at crate2 distributor0)
	(at pallet3 distributor0)
	(on crate3 pallet3)
	(on crate7 crate3)
	(at crate1 depot0)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate8 depot0)
	(clear pallet5)
	(on crate5 pallet4)
	(at crate5 depot0)
	(at crate6 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate2 pallet0)
	(at hoist1 distributor0)
	(at crate7 distributor0)
	(at pallet1 depot0)
	(on crate4 crate5)
	(clear crate2)
	(on crate8 crate6)
	(on crate6 crate4)
	(at crate9 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)