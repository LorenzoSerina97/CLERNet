(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet3 depot0)
	(at truck1 depot2)
	(clear crate0)
	(at hoist1 depot1)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(available hoist1)
	(at truck2 depot2)
	(available hoist2)
	(at hoist5 distributor2)
	(at crate0 depot0)
	(available hoist3)
	(at pallet5 depot2)
	(available hoist4)
	(at pallet1 distributor0)
	(clear pallet5)
	(at crate2 depot1)
	(at crate1 distributor2)
	(at pallet0 distributor2)
	(on crate1 pallet0)
	(at truck0 depot0)
	(on crate0 pallet3)
	(at pallet2 depot1)
	(at hoist4 distributor1)
	(at hoist3 depot2)
	(clear crate2)
	(at hoist0 distributor0)
	(at hoist2 depot0)
	(on crate2 pallet2)
	(clear pallet4)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)