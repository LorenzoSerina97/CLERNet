(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		crate0 - Crate
		crate1 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
)
(:init

	(at truck1 depot1)
	(clear pallet3)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate1 crate0)
	(at hoist0 depot1)
	(available hoist2)
	(available hoist3)
	(at hoist3 distributor1)
	(at hoist1 depot0)
	(at crate0 distributor0)
	(at truck0 depot0)
	(at crate1 distributor0)
	(clear pallet0)
	(at pallet1 depot1)
	(at pallet0 depot0)
	(on crate0 pallet2)
	(at pallet3 distributor1)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)