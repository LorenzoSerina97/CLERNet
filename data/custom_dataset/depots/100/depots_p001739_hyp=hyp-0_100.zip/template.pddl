(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate9 pallet0)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(on crate0 pallet5)
	(clear pallet2)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(on crate6 pallet3)
	(at crate0 depot0)
	(on crate2 crate8)
	(at pallet4 distributor0)
	(at crate1 depot0)
	(on crate1 crate6)
	(on crate3 crate9)
	(at crate4 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate5 crate3)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(at crate7 distributor0)
	(clear crate2)
	(on crate7 pallet4)
	(on crate4 crate7)
	(at crate8 distributor1)
	(clear crate4)
	(at crate5 distributor0)
	(on crate8 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)