(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(at pallet4 depot0)
	(on crate3 pallet5)
	(clear crate0)
	(on crate0 crate1)
	(at crate7 distributor1)
	(on crate4 crate8)
	(on crate8 crate7)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate5)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate5 crate6)
	(available hoist2)
	(on crate6 crate9)
	(on crate9 pallet3)
	(clear crate4)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(on crate2 pallet4)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(at crate5 depot0)
	(on crate1 pallet0)
	(at hoist0 depot0)
	(clear crate3)
	(clear crate2)
	(at crate2 depot0)
	(at crate0 distributor1)
	(on crate7 pallet2)
	(at crate9 depot0)
	(at crate8 distributor1)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)