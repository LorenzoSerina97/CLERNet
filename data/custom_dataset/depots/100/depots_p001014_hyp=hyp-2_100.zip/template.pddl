(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at crate3 distributor0)
	(clear pallet3)
	(at pallet4 depot0)
	(on crate3 pallet5)
	(on crate7 crate1)
	(clear crate0)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(on crate9 pallet2)
	(clear crate5)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate6 crate3)
	(available hoist2)
	(on crate8 crate9)
	(at crate0 depot0)
	(on crate4 pallet0)
	(at pallet3 distributor0)
	(at crate1 depot0)
	(at truck1 distributor0)
	(on crate0 crate2)
	(on crate1 pallet4)
	(at pallet2 distributor1)
	(at crate6 distributor0)
	(at crate9 distributor1)
	(at pallet1 distributor0)
	(at truck0 depot0)
	(on crate2 crate7)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(at hoist2 depot0)
	(clear crate8)
	(at crate8 distributor1)
	(on crate5 pallet1)
	(clear crate4)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)