(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate5 distributor0)
	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(clear pallet3)
	(clear pallet2)
	(clear crate0)
	(on crate4 crate1)
	(on crate0 pallet0)
	(available hoist0)
	(at hoist2 distributor1)
	(on crate9 crate3)
	(available hoist1)
	(on crate7 pallet1)
	(on crate5 crate6)
	(on crate3 crate4)
	(available hoist2)
	(on crate6 pallet4)
	(at crate2 distributor1)
	(at crate0 depot0)
	(at pallet4 distributor0)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate6 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at hoist0 depot0)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(at truck1 depot0)
	(at crate7 distributor0)
	(on crate1 crate5)
	(clear crate9)
	(at pallet0 depot0)
	(on crate8 crate2)
	(clear crate8)
	(at crate8 distributor1)
	(on crate2 pallet5)
)
(:goal 
(and
<HYPOTHESIS>
))
)