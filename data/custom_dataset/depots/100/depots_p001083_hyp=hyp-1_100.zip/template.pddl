(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 depot0)
	(at crate3 distributor0)
	(at pallet4 depot0)
	(at crate6 distributor1)
	(clear crate0)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet0 distributor1)
	(available hoist1)
	(available hoist2)
	(on crate8 pallet0)
	(on crate4 pallet2)
	(at pallet3 distributor0)
	(on crate3 pallet3)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(on crate1 crate6)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(at pallet1 distributor0)
	(clear pallet5)
	(at crate9 distributor0)
	(at hoist0 depot0)
	(on crate5 crate3)
	(on crate0 crate8)
	(on crate2 crate7)
	(clear crate2)
	(clear crate9)
	(at crate0 distributor1)
	(at crate2 depot0)
	(on crate7 pallet4)
	(on crate6 crate4)
	(on crate9 crate5)
	(at crate8 distributor1)
	(clear pallet1)
	(at hoist2 distributor0)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)