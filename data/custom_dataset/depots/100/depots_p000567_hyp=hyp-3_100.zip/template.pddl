(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
)
(:init

	(at crate3 distributor0)
	(on crate0 pallet0)
	(available hoist0)
	(clear crate1)
	(on crate6 crate3)
	(available hoist1)
	(on crate5 crate6)
	(on crate1 crate0)
	(on crate4 crate2)
	(on crate2 crate5)
	(at crate0 depot0)
	(at crate2 distributor0)
	(at crate1 depot0)
	(at truck1 distributor0)
	(clear crate7)
	(at crate6 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at hoist0 depot0)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(at crate7 distributor0)
	(at pallet0 depot0)
	(on crate3 pallet1)
	(on crate7 crate4)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)