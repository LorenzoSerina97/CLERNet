(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(on crate3 pallet5)
	(on crate9 crate2)
	(clear pallet2)
	(on crate0 crate1)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(clear crate5)
	(on crate6 crate3)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet2 depot0)
	(at pallet0 distributor0)
	(on crate8 pallet3)
	(on crate1 crate8)
	(at crate0 depot0)
	(on crate4 pallet0)
	(at crate2 distributor1)
	(at crate1 depot0)
	(at truck1 distributor0)
	(clear crate7)
	(at crate6 distributor0)
	(on crate5 crate4)
	(at crate8 depot0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(on crate2 pallet4)
	(at crate9 distributor1)
	(at hoist0 depot0)
	(at truck0 depot0)
	(clear crate9)
	(on crate7 crate0)
	(clear pallet1)
	(at hoist2 distributor0)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)