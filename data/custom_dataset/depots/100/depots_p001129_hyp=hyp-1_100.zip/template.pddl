(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate1 crate2)
	(on crate9 pallet0)
	(at crate3 distributor0)
	(at crate6 distributor1)
	(on crate2 crate4)
	(at crate4 distributor1)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(clear crate7)
	(at crate5 distributor1)
	(at crate0 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(clear pallet5)
	(at hoist1 distributor0)
	(on crate3 crate0)
	(at hoist0 distributor1)
	(clear crate3)
	(at truck1 depot0)
	(at crate7 distributor0)
	(on crate5 pallet3)
	(on crate8 crate6)
	(at hoist2 depot0)
	(on crate6 pallet1)
	(on crate0 pallet2)
	(clear crate8)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(on crate7 crate9)
	(on crate4 pallet4)
)
(:goal 
(and
<HYPOTHESIS>
))
)