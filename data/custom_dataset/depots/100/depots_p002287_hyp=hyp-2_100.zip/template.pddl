(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at truck0 depot1)
	(at crate3 depot0)
	(clear pallet2)
	(on crate0 crate1)
	(on crate5 pallet0)
	(available hoist0)
	(available hoist1)
	(at hoist0 depot1)
	(available hoist2)
	(at truck1 distributor0)
	(on crate4 crate0)
	(on crate3 crate5)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at crate5 depot0)
	(on crate2 crate3)
	(at crate1 distributor0)
	(at hoist1 distributor0)
	(at pallet2 depot1)
	(clear crate2)
	(on crate1 pallet1)
	(at crate2 depot0)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)