(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate2 crate1)
	(at pallet3 depot0)
	(clear pallet3)
	(at pallet4 depot1)
	(at truck1 depot2)
	(clear crate0)
	(at truck2 depot1)
	(available hoist0)
	(available hoist1)
	(at hoist5 depot1)
	(available hoist2)
	(available hoist3)
	(at truck0 distributor2)
	(at hoist3 distributor1)
	(at pallet5 depot2)
	(at pallet2 distributor1)
	(available hoist4)
	(at pallet1 distributor0)
	(clear pallet5)
	(at hoist4 distributor2)
	(at crate1 distributor2)
	(at pallet0 distributor2)
	(at hoist0 depot0)
	(on crate1 pallet0)
	(clear crate2)
	(at crate0 distributor1)
	(at crate2 distributor2)
	(at hoist1 depot2)
	(clear pallet4)
	(on crate0 pallet2)
	(available hoist5)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)