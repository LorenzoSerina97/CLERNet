(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate9 pallet0)
	(at pallet3 depot0)
	(at crate3 depot0)
	(on crate5 pallet5)
	(on crate0 crate1)
	(available hoist0)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(at pallet5 distributor0)
	(at pallet0 distributor1)
	(at crate8 distributor0)
	(available hoist2)
	(on crate2 crate0)
	(on crate7 crate6)
	(at crate2 distributor0)
	(on crate3 pallet3)
	(at pallet4 distributor0)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(clear crate7)
	(at crate6 distributor0)
	(at crate9 distributor1)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(on crate1 pallet2)
	(at crate1 distributor0)
	(at hoist0 distributor1)
	(clear crate3)
	(at crate7 distributor0)
	(at pallet1 depot0)
	(clear crate9)
	(on crate8 crate2)
	(on crate6 crate4)
	(clear crate8)
	(clear pallet1)
	(on crate4 pallet4)
	(at hoist2 distributor0)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)