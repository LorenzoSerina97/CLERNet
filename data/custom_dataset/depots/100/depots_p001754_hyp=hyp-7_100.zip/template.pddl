(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate1 crate2)
	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(on crate6 crate7)
	(at crate6 distributor1)
	(clear crate0)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(clear crate6)
	(clear crate5)
	(available hoist1)
	(at pallet0 distributor1)
	(available hoist2)
	(at pallet2 depot0)
	(at crate2 distributor1)
	(on crate2 crate8)
	(at crate0 depot0)
	(at crate4 depot0)
	(at crate1 distributor1)
	(at hoist1 depot0)
	(on crate8 pallet5)
	(on crate5 crate4)
	(at crate9 distributor1)
	(on crate9 pallet4)
	(at pallet1 distributor0)
	(at crate5 depot0)
	(at truck0 depot0)
	(on crate4 pallet3)
	(at hoist0 distributor1)
	(clear crate3)
	(at truck1 depot0)
	(on crate7 pallet0)
	(clear crate9)
	(on crate3 pallet1)
	(on crate0 pallet2)
	(at crate8 distributor1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)