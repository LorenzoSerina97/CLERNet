(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet4 depot0)
	(clear crate0)
	(on crate3 crate2)
	(available hoist0)
	(clear crate6)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(on crate5 crate1)
	(at pallet0 distributor0)
	(on crate9 pallet3)
	(on crate4 pallet0)
	(at crate2 distributor0)
	(at crate0 depot0)
	(at pallet3 distributor0)
	(at crate1 depot0)
	(at truck1 distributor0)
	(on crate8 pallet5)
	(on crate0 crate5)
	(at crate6 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at crate5 depot0)
	(at hoist0 depot0)
	(on crate1 pallet2)
	(at truck0 depot0)
	(on crate2 crate7)
	(clear crate3)
	(at crate7 distributor0)
	(on crate6 crate4)
	(clear pallet4)
	(clear crate8)
	(at crate8 distributor1)
	(on crate7 crate9)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)