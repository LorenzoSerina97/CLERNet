(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at truck1 depot1)
	(clear pallet3)
	(at truck2 distributor2)
	(at truck0 depot1)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(available hoist1)
	(at hoist5 depot1)
	(on crate1 crate0)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(available hoist3)
	(at hoist3 distributor1)
	(at pallet3 distributor2)
	(available hoist4)
	(at pallet2 depot2)
	(on crate2 pallet4)
	(clear pallet5)
	(at hoist4 distributor2)
	(at pallet5 depot1)
	(clear pallet0)
	(at crate0 depot2)
	(at pallet1 depot0)
	(clear crate2)
	(at hoist0 distributor0)
	(at crate1 depot2)
	(at hoist2 depot0)
	(at hoist1 depot2)
	(on crate0 pallet2)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)