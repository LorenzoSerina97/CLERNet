(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate5 distributor0)
	(at pallet5 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(at pallet4 depot0)
	(clear crate0)
	(on crate4 crate8)
	(available hoist0)
	(clear crate6)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate0 crate4)
	(available hoist2)
	(on crate5 crate1)
	(on crate6 pallet4)
	(at crate2 distributor1)
	(on crate8 pallet3)
	(at crate0 depot0)
	(on crate7 crate3)
	(at crate4 depot0)
	(on crate9 crate7)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at crate6 depot0)
	(at truck1 distributor1)
	(on crate1 pallet2)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(at hoist0 distributor1)
	(clear pallet0)
	(at crate7 distributor0)
	(clear crate2)
	(clear crate9)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(on crate3 pallet1)
	(at truck0 distributor1)
	(on crate2 pallet5)
)
(:goal 
(and
<HYPOTHESIS>
))
)