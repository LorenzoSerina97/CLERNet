(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		crate0 - Crate
		crate1 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
)
(:init

	(clear pallet3)
	(clear crate0)
	(at hoist1 depot1)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate0 pallet1)
	(available hoist2)
	(at pallet3 depot1)
	(available hoist3)
	(at hoist3 distributor0)
	(at pallet1 distributor1)
	(at truck1 distributor1)
	(on crate1 pallet2)
	(at crate1 distributor0)
	(at hoist0 distributor1)
	(clear pallet0)
	(at crate0 distributor1)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(at truck0 distributor1)
)
(:goal 
(and
<HYPOTHESIS>
))
)