(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet0 depot1)
	(at pallet3 depot0)
	(clear pallet3)
	(clear crate0)
	(at hoist1 distributor2)
	(clear crate1)
	(available hoist0)
	(on crate0 pallet1)
	(available hoist1)
	(at pallet5 distributor0)
	(at pallet1 distributor2)
	(available hoist2)
	(at truck2 distributor1)
	(at crate2 distributor1)
	(available hoist3)
	(at truck0 distributor2)
	(at crate0 distributor2)
	(on crate1 pallet4)
	(at pallet2 distributor1)
	(available hoist4)
	(clear pallet5)
	(at truck1 distributor1)
	(at hoist3 depot1)
	(at hoist4 depot0)
	(at hoist0 distributor1)
	(clear pallet0)
	(at hoist5 depot2)
	(clear crate2)
	(at crate1 depot2)
	(at pallet4 depot2)
	(on crate2 pallet2)
	(available hoist5)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)