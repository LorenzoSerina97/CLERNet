(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(on crate1 crate2)
	(at pallet5 distributor1)
	(clear pallet3)
	(at pallet4 depot0)
	(on crate3 pallet5)
	(on crate7 crate1)
	(at crate6 distributor1)
	(clear crate0)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(at pallet0 distributor1)
	(available hoist2)
	(on crate8 crate9)
	(at crate2 distributor1)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(clear crate7)
	(at crate9 distributor1)
	(at crate0 distributor0)
	(on crate5 crate4)
	(at pallet1 distributor1)
	(at crate5 depot0)
	(at hoist0 depot0)
	(on crate2 crate3)
	(on crate9 crate6)
	(at crate3 distributor1)
	(at truck0 distributor1)
	(on crate0 pallet2)
	(clear crate8)
	(on crate6 pallet0)
	(at crate8 distributor1)
	(clear pallet1)
	(on crate4 pallet4)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)