(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 distributor1)
	(on crate2 crate9)
	(clear crate0)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate3 crate7)
	(available hoist2)
	(on crate7 pallet3)
	(on crate4 crate2)
	(on crate6 pallet4)
	(at crate4 depot0)
	(at pallet4 distributor0)
	(at truck1 distributor0)
	(on crate8 pallet5)
	(at crate6 distributor0)
	(at crate5 depot0)
	(on crate1 pallet2)
	(at truck0 depot0)
	(at crate1 distributor0)
	(at crate3 distributor1)
	(clear pallet0)
	(at pallet1 depot0)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(at crate0 distributor1)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(on crate9 crate5)
	(clear crate8)
	(on crate5 pallet1)
	(at pallet3 distributor1)
	(at crate9 depot0)
	(at crate8 distributor1)
	(on crate0 crate3)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)