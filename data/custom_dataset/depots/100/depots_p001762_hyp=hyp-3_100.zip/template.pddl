(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate4 pallet5)
	(on crate9 crate2)
	(clear pallet2)
	(on crate2 crate4)
	(clear crate0)
	(on crate5 pallet0)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(at hoist2 distributor1)
	(clear crate5)
	(at pallet2 distributor0)
	(at pallet5 distributor0)
	(available hoist1)
	(at crate8 distributor0)
	(on crate3 pallet4)
	(available hoist2)
	(at pallet0 distributor0)
	(on crate8 pallet3)
	(on crate7 crate6)
	(at crate2 distributor0)
	(at pallet3 distributor0)
	(at truck0 distributor0)
	(clear crate7)
	(at crate4 distributor0)
	(at crate9 distributor0)
	(at crate6 depot0)
	(on crate1 crate9)
	(at hoist0 depot0)
	(at hoist1 distributor0)
	(at crate3 distributor1)
	(at crate1 distributor0)
	(at truck1 depot0)
	(at pallet1 depot0)
	(at crate0 distributor1)
	(on crate6 pallet1)
	(clear crate8)
	(on crate0 crate3)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)