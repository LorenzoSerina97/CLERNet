(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(at pallet3 depot0)
	(at crate3 depot0)
	(clear pallet2)
	(clear crate0)
	(available hoist0)
	(clear crate6)
	(at hoist2 distributor1)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate7 pallet1)
	(at crate8 distributor0)
	(on crate9 crate3)
	(available hoist2)
	(at pallet2 depot0)
	(on crate5 crate1)
	(on crate4 crate2)
	(on crate2 crate5)
	(at crate0 depot0)
	(on crate3 pallet3)
	(on crate0 crate7)
	(at crate4 depot0)
	(at pallet4 distributor0)
	(at crate1 depot0)
	(at hoist1 depot0)
	(on crate1 pallet5)
	(at crate6 distributor0)
	(at crate5 depot0)
	(at truck0 depot0)
	(on crate6 crate8)
	(clear pallet0)
	(at truck1 depot0)
	(at pallet1 depot0)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(at crate9 depot0)
	(clear crate4)
	(on crate8 pallet4)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)