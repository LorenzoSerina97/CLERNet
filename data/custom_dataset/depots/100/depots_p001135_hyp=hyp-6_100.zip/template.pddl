(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate5 crate9)
	(at crate5 distributor0)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(clear pallet3)
	(at pallet4 depot0)
	(clear crate0)
	(on crate0 pallet0)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at hoist2 distributor1)
	(at pallet2 distributor0)
	(available hoist1)
	(at pallet5 distributor0)
	(at pallet0 distributor1)
	(on crate3 crate7)
	(on crate9 pallet2)
	(available hoist2)
	(on crate6 crate5)
	(at crate2 distributor0)
	(at crate4 depot0)
	(at crate1 depot0)
	(on crate7 crate2)
	(at crate6 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at hoist1 distributor0)
	(clear crate3)
	(at crate7 distributor0)
	(on crate1 crate4)
	(at crate0 distributor1)
	(at truck0 distributor1)
	(clear crate8)
	(at crate8 distributor1)
	(on crate4 pallet4)
	(on crate2 pallet5)
	(on crate8 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)