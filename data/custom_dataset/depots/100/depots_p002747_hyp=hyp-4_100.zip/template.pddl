(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate3 distributor0)
	(at hoist2 depot1)
	(clear crate0)
	(on crate5 pallet0)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate3 crate4)
	(available hoist2)
	(on crate4 pallet2)
	(at crate2 distributor0)
	(at crate1 depot0)
	(on crate0 crate2)
	(at hoist1 depot0)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at crate5 depot0)
	(on crate2 crate3)
	(at truck0 depot0)
	(at truck1 depot0)
	(on crate1 crate5)
	(at hoist0 distributor0)
	(at pallet1 depot1)
	(at pallet0 depot0)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)