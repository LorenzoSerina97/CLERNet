(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet0 depot1)
	(on crate0 pallet5)
	(at pallet4 depot0)
	(at pallet1 depot2)
	(at truck0 depot1)
	(clear pallet2)
	(clear crate0)
	(at hoist1 depot1)
	(available hoist0)
	(clear crate1)
	(at hoist2 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(at hoist5 distributor0)
	(available hoist2)
	(at hoist3 distributor2)
	(at crate2 distributor1)
	(at truck2 distributor0)
	(available hoist3)
	(at crate1 depot0)
	(on crate1 pallet4)
	(at pallet2 distributor2)
	(available hoist4)
	(at crate0 distributor0)
	(at hoist4 depot2)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(clear pallet0)
	(on crate2 pallet3)
	(clear crate2)
	(at pallet3 distributor1)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)