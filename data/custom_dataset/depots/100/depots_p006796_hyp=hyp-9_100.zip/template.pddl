(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate0 pallet5)
	(clear pallet3)
	(at pallet4 depot1)
	(at crate2 depot2)
	(at truck1 distributor2)
	(clear crate1)
	(available hoist0)
	(at hoist2 distributor1)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(at hoist5 depot1)
	(on crate1 crate0)
	(available hoist2)
	(at truck2 distributor1)
	(available hoist3)
	(at pallet3 distributor2)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at hoist3 distributor0)
	(available hoist4)
	(at pallet2 depot2)
	(at crate0 distributor0)
	(at hoist4 distributor2)
	(at crate1 distributor0)
	(clear pallet0)
	(at pallet1 depot0)
	(clear crate2)
	(on crate2 pallet2)
	(clear pallet4)
	(available hoist5)
	(at hoist0 depot2)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)