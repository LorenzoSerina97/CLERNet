(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate4 pallet1)
	(at pallet4 depot0)
	(at crate3 depot0)
	(on crate5 pallet0)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at hoist2 distributor1)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate9 pallet2)
	(at crate4 distributor1)
	(on crate1 crate0)
	(on crate3 pallet4)
	(available hoist2)
	(on crate6 crate9)
	(at pallet0 distributor0)
	(on crate8 pallet3)
	(at crate1 distributor1)
	(clear crate7)
	(on crate2 pallet5)
	(on crate7 crate2)
	(at crate6 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate0 crate8)
	(at hoist1 distributor0)
	(clear crate3)
	(at crate0 distributor1)
	(at crate2 depot0)
	(at truck0 distributor1)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(clear crate4)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)