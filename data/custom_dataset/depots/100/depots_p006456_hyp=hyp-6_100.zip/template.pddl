(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet0 depot1)
	(on crate2 crate1)
	(clear pallet3)
	(at hoist5 distributor1)
	(at truck1 depot2)
	(clear pallet2)
	(clear crate0)
	(at truck2 depot1)
	(available hoist0)
	(at pallet4 distributor1)
	(available hoist1)
	(at hoist0 depot1)
	(at pallet2 depot0)
	(available hoist2)
	(available hoist3)
	(on crate0 crate2)
	(at truck0 distributor2)
	(at crate0 distributor2)
	(at hoist3 distributor0)
	(at hoist2 distributor2)
	(at pallet5 distributor2)
	(available hoist4)
	(on crate1 pallet5)
	(at pallet1 distributor0)
	(at crate1 distributor2)
	(at hoist4 depot0)
	(clear pallet0)
	(at crate2 distributor2)
	(at pallet3 depot2)
	(at hoist1 depot2)
	(clear pallet4)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)