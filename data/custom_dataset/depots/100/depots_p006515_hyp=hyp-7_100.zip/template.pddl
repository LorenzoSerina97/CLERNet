(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at truck0 depot2)
	(on crate0 pallet5)
	(at pallet3 depot0)
	(at hoist2 depot1)
	(clear pallet2)
	(clear crate0)
	(at truck2 depot1)
	(clear crate1)
	(available hoist0)
	(available hoist1)
	(available hoist2)
	(at pallet0 distributor0)
	(available hoist3)
	(at pallet5 depot2)
	(at hoist3 depot0)
	(available hoist4)
	(at hoist0 distributor2)
	(at pallet1 distributor1)
	(on crate1 pallet0)
	(at truck1 distributor1)
	(at crate1 distributor0)
	(at pallet2 depot1)
	(at crate0 depot2)
	(at hoist5 depot2)
	(on crate2 pallet3)
	(at hoist4 distributor0)
	(clear crate2)
	(at crate2 depot0)
	(at pallet4 distributor2)
	(clear pallet4)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)