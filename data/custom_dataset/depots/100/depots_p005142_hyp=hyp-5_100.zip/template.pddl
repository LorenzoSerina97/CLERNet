(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
)
(:init

	(at crate3 depot0)
	(available hoist0)
	(on crate6 crate3)
	(clear crate5)
	(available hoist1)
	(on crate5 crate1)
	(at pallet0 distributor0)
	(at crate0 depot0)
	(at crate4 depot0)
	(on crate0 crate2)
	(at hoist1 depot0)
	(clear crate7)
	(on crate1 pallet0)
	(at crate6 depot0)
	(at truck0 depot0)
	(at crate1 distributor0)
	(on crate3 crate0)
	(at truck1 depot0)
	(at pallet1 depot0)
	(on crate4 crate6)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(on crate7 crate4)
	(at crate5 distributor0)
	(on crate2 pallet1)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)