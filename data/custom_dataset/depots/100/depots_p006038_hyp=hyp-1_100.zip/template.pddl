(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate0 pallet5)
	(at hoist2 depot1)
	(at truck0 depot1)
	(at truck1 depot2)
	(clear crate0)
	(clear crate1)
	(available hoist0)
	(at pallet0 distributor1)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(at hoist3 distributor2)
	(available hoist3)
	(at crate1 depot0)
	(at pallet3 distributor2)
	(at hoist1 depot0)
	(available hoist4)
	(at pallet1 distributor0)
	(on crate1 pallet2)
	(at pallet5 depot1)
	(at truck2 depot0)
	(at hoist0 distributor1)
	(clear pallet0)
	(at hoist5 depot2)
	(on crate2 pallet3)
	(at hoist4 distributor0)
	(clear crate2)
	(at crate2 distributor2)
	(at pallet4 depot2)
	(clear pallet4)
	(available hoist5)
	(clear pallet1)
	(at crate0 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)