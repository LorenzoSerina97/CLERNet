(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 depot0)
	(clear pallet3)
	(at pallet4 depot0)
	(at crate3 depot0)
	(on crate3 pallet5)
	(available hoist0)
	(clear crate5)
	(on crate0 crate4)
	(available hoist1)
	(on crate5 crate6)
	(available hoist2)
	(at crate2 distributor1)
	(on crate2 crate8)
	(at crate0 depot0)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(on crate9 crate1)
	(at pallet2 distributor1)
	(clear crate7)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at crate6 depot0)
	(at crate5 depot0)
	(at truck1 distributor1)
	(at crate1 distributor0)
	(clear crate3)
	(clear crate2)
	(clear crate9)
	(at hoist0 distributor0)
	(on crate1 pallet1)
	(at pallet0 depot0)
	(on crate7 crate0)
	(at hoist2 depot0)
	(at truck0 distributor1)
	(at crate8 distributor1)
	(on crate6 pallet0)
	(on crate4 pallet4)
	(on crate8 pallet2)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)