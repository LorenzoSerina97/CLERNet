(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(at pallet3 depot0)
	(on crate5 crate7)
	(on crate3 pallet5)
	(on crate2 crate9)
	(on crate0 pallet0)
	(clear crate1)
	(clear crate6)
	(available hoist0)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate9 pallet2)
	(available hoist2)
	(at pallet2 depot0)
	(on crate8 pallet3)
	(at crate0 depot0)
	(at crate4 depot0)
	(at pallet4 distributor0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at hoist1 depot0)
	(on crate4 crate0)
	(at crate8 depot0)
	(at crate6 depot0)
	(at crate5 depot0)
	(at crate3 distributor1)
	(on crate1 crate3)
	(at pallet1 depot0)
	(clear crate2)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate7 crate8)
	(on crate6 pallet1)
	(at truck0 distributor1)
	(clear pallet4)
	(at crate9 depot0)
	(clear crate4)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)