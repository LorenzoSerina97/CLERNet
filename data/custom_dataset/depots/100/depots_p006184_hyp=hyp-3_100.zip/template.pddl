(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet0 depot1)
	(at truck0 depot2)
	(at truck1 depot1)
	(clear pallet3)
	(at truck2 distributor2)
	(at pallet4 depot0)
	(clear pallet2)
	(available hoist0)
	(clear crate1)
	(on crate0 pallet1)
	(at hoist5 depot1)
	(available hoist1)
	(on crate1 crate0)
	(available hoist2)
	(at hoist3 distributor2)
	(at pallet3 distributor0)
	(available hoist3)
	(at crate1 distributor1)
	(at pallet5 distributor2)
	(available hoist4)
	(at pallet2 depot2)
	(at crate2 depot1)
	(at pallet1 distributor1)
	(clear pallet5)
	(on crate2 pallet0)
	(at hoist4 depot0)
	(clear crate2)
	(at crate0 distributor1)
	(clear pallet4)
	(available hoist5)
	(at hoist0 depot2)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)