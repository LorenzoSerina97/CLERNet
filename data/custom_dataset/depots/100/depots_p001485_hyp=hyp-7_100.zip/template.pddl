(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(clear pallet2)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate5 crate6)
	(on crate1 crate0)
	(available hoist2)
	(on crate9 pallet1)
	(on crate2 crate5)
	(on crate4 pallet0)
	(at crate4 depot0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(on crate3 crate9)
	(clear crate7)
	(on crate8 pallet5)
	(on crate7 crate2)
	(at crate9 distributor1)
	(at crate8 depot0)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(at crate5 depot0)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(on crate0 pallet3)
	(at crate3 distributor1)
	(at hoist0 distributor1)
	(on crate6 crate8)
	(clear crate3)
	(at crate0 distributor1)
	(at crate2 depot0)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(clear pallet4)
	(at pallet3 distributor1)
	(clear crate4)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)