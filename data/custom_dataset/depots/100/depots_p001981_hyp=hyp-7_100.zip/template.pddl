(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet3 depot0)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(on crate3 pallet2)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet0 distributor0)
	(on crate1 crate8)
	(on crate4 pallet0)
	(clear crate4)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(clear crate7)
	(on crate0 crate5)
	(at crate6 distributor0)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate9 crate6)
	(at crate3 distributor1)
	(on crate6 pallet5)
	(at crate7 distributor0)
	(on crate2 pallet3)
	(clear crate2)
	(clear crate9)
	(at crate2 depot0)
	(on crate7 crate0)
	(clear pallet4)
	(on crate8 crate3)
	(on crate5 pallet1)
	(at crate8 distributor1)
	(at hoist2 distributor0)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)