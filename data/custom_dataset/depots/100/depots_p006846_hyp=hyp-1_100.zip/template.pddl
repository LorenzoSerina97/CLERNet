(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(clear pallet3)
	(clear pallet2)
	(clear crate1)
	(available hoist0)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate0 pallet1)
	(at pallet1 distributor2)
	(available hoist2)
	(at pallet2 depot0)
	(on crate2 crate0)
	(at pallet3 depot1)
	(at pallet4 distributor0)
	(available hoist3)
	(at pallet5 depot2)
	(at crate0 distributor2)
	(on crate1 pallet4)
	(at hoist2 distributor2)
	(available hoist4)
	(clear pallet5)
	(at hoist3 depot1)
	(at crate1 distributor0)
	(at truck2 depot0)
	(at hoist4 distributor1)
	(clear pallet0)
	(at truck1 depot0)
	(clear crate2)
	(at hoist0 distributor0)
	(at crate2 distributor2)
	(at hoist5 depot0)
	(at truck0 distributor1)
	(at hoist1 depot2)
	(available hoist5)
)
(:goal 
(and
<HYPOTHESIS>
))
)