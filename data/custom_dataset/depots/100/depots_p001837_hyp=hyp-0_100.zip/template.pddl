(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(at crate3 depot0)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate7 pallet1)
	(available hoist2)
	(at pallet2 depot0)
	(on crate6 pallet4)
	(at crate0 depot0)
	(at crate4 depot0)
	(on crate4 pallet2)
	(at pallet3 distributor0)
	(at pallet4 distributor0)
	(on crate8 pallet0)
	(at crate1 depot0)
	(on crate3 crate9)
	(at crate6 distributor0)
	(at crate8 depot0)
	(clear pallet5)
	(at hoist0 depot0)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(on crate0 crate8)
	(on crate2 crate7)
	(clear crate3)
	(at truck1 depot0)
	(at pallet1 depot0)
	(on crate1 crate4)
	(clear crate2)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate5 pallet3)
	(on crate9 crate0)
	(at crate9 depot0)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)