(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 depot0)
	(at crate3 distributor0)
	(on crate0 pallet0)
	(on crate8 crate7)
	(on crate4 crate9)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(clear crate5)
	(at crate8 distributor0)
	(available hoist1)
	(available hoist2)
	(on crate7 pallet3)
	(on crate5 crate1)
	(on crate9 pallet1)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(at pallet3 distributor0)
	(clear crate4)
	(at crate1 distributor1)
	(at pallet2 distributor1)
	(at crate5 distributor1)
	(at crate9 distributor1)
	(at crate0 distributor0)
	(on crate2 pallet4)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(at hoist0 depot0)
	(on crate1 pallet2)
	(on crate3 crate0)
	(on crate6 pallet5)
	(clear crate3)
	(at truck1 depot0)
	(at crate7 distributor0)
	(clear crate2)
	(at truck0 distributor1)
	(clear crate8)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)