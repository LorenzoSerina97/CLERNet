(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate3 crate6)
	(at hoist1 distributor1)
	(on crate4 pallet5)
	(at pallet5 depot0)
	(at crate3 distributor0)
	(on crate5 crate7)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(at crate8 distributor0)
	(available hoist1)
	(on crate7 pallet1)
	(available hoist2)
	(on crate8 pallet3)
	(at crate2 distributor0)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(at pallet4 distributor0)
	(on crate0 crate2)
	(at crate1 distributor1)
	(at pallet2 distributor1)
	(at crate5 distributor1)
	(at crate6 distributor0)
	(at crate0 distributor0)
	(on crate2 pallet4)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at truck1 distributor1)
	(on crate1 pallet2)
	(at truck0 depot0)
	(on crate6 crate8)
	(clear pallet0)
	(clear crate3)
	(clear crate9)
	(at hoist0 distributor0)
	(at pallet0 depot0)
	(at hoist2 depot0)
	(on crate9 crate0)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)