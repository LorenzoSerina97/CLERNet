(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(at pallet4 depot0)
	(on crate0 crate1)
	(on crate5 pallet5)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate3 pallet2)
	(at crate8 distributor0)
	(available hoist2)
	(at pallet0 distributor0)
	(on crate8 crate0)
	(at crate2 distributor0)
	(at pallet3 distributor0)
	(on crate1 crate6)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at pallet2 distributor1)
	(on crate9 crate7)
	(at crate6 distributor0)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(at crate9 distributor0)
	(at crate5 depot0)
	(at crate1 distributor0)
	(at crate3 distributor1)
	(at truck1 depot0)
	(at crate7 distributor0)
	(on crate7 pallet0)
	(on crate4 crate3)
	(on crate2 pallet3)
	(clear crate2)
	(clear crate9)
	(at hoist0 distributor0)
	(on crate6 pallet1)
	(clear pallet4)
	(clear crate8)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)