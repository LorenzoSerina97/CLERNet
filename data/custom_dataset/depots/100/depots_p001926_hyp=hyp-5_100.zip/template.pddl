(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(clear crate0)
	(on crate5 pallet5)
	(at crate7 distributor1)
	(on crate4 crate1)
	(on crate3 crate2)
	(available hoist0)
	(at pallet4 distributor1)
	(at hoist2 distributor1)
	(clear crate5)
	(at pallet0 distributor1)
	(at pallet5 distributor0)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(at crate2 distributor1)
	(on crate9 pallet3)
	(at crate4 depot0)
	(at crate1 depot0)
	(at truck0 distributor0)
	(clear crate7)
	(at crate6 distributor0)
	(at crate9 distributor1)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(on crate2 pallet0)
	(on crate0 crate6)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate1 pallet2)
	(at hoist1 distributor0)
	(at crate3 distributor1)
	(clear crate9)
	(on crate7 crate8)
	(on crate6 pallet1)
	(clear pallet4)
	(on crate8 crate3)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(clear crate4)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)