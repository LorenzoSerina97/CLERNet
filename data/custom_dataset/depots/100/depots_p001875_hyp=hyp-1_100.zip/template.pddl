(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate4 pallet5)
	(at hoist1 distributor1)
	(at pallet5 depot0)
	(at crate3 distributor0)
	(on crate2 crate9)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(on crate9 pallet2)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate0 pallet1)
	(available hoist2)
	(on crate6 crate5)
	(at crate4 depot0)
	(on crate3 pallet3)
	(at pallet3 distributor0)
	(at pallet4 distributor0)
	(on crate8 pallet0)
	(at crate2 distributor0)
	(at truck1 distributor0)
	(on crate1 crate6)
	(clear crate7)
	(at crate6 distributor0)
	(at crate8 depot0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(on crate5 pallet4)
	(at hoist0 depot0)
	(at truck0 depot0)
	(at crate1 distributor0)
	(clear crate3)
	(clear crate2)
	(at crate0 distributor1)
	(at pallet0 depot0)
	(on crate7 crate0)
	(clear crate8)
	(at hoist2 distributor0)
	(clear crate4)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)