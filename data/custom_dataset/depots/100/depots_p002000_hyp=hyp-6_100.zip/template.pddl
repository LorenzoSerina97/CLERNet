(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate3 depot0)
	(on crate6 crate2)
	(clear crate0)
	(on crate4 crate8)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at hoist2 distributor1)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(at crate8 distributor0)
	(available hoist2)
	(at pallet2 depot0)
	(on crate0 crate9)
	(at pallet3 distributor0)
	(at pallet4 distributor0)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(clear crate7)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at crate9 distributor0)
	(clear pallet5)
	(on crate1 pallet0)
	(at crate6 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate2 crate3)
	(at hoist1 distributor0)
	(at pallet1 depot0)
	(at crate2 depot0)
	(on crate5 pallet3)
	(on crate9 crate5)
	(on crate3 pallet1)
	(on crate7 pallet2)
	(clear crate4)
	(at crate5 distributor0)
	(on crate8 pallet4)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)