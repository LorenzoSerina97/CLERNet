(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet3 depot0)
	(clear crate0)
	(on crate0 crate1)
	(on crate4 crate9)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(clear crate5)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate3 pallet4)
	(available hoist2)
	(at crate2 distributor1)
	(on crate6 pallet3)
	(at crate0 depot0)
	(at crate1 depot0)
	(on crate9 pallet5)
	(at hoist1 depot0)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate5 distributor1)
	(at crate4 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(on crate1 pallet0)
	(at crate6 depot0)
	(at truck1 distributor1)
	(at truck0 depot0)
	(at crate3 distributor1)
	(at hoist0 distributor1)
	(clear crate3)
	(at crate7 distributor0)
	(at pallet0 depot0)
	(on crate8 crate2)
	(on crate5 crate8)
	(on crate2 pallet2)
	(on crate7 crate4)
	(at crate8 distributor1)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)