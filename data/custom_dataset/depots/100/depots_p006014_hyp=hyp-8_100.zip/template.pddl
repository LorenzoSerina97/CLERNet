(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at hoist5 distributor1)
	(clear pallet2)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(available hoist1)
	(at pallet1 distributor2)
	(on crate1 crate0)
	(at hoist0 depot1)
	(at pallet2 depot0)
	(available hoist2)
	(at truck2 distributor0)
	(at pallet0 depot2)
	(at pallet3 distributor0)
	(available hoist3)
	(at truck0 distributor2)
	(at hoist2 distributor2)
	(available hoist4)
	(at crate0 distributor0)
	(clear pallet5)
	(at pallet5 depot1)
	(at hoist1 distributor0)
	(on crate0 pallet3)
	(at crate1 distributor0)
	(at hoist4 depot0)
	(clear pallet0)
	(at truck1 depot0)
	(at hoist3 depot2)
	(clear crate2)
	(at crate2 distributor2)
	(clear pallet4)
	(available hoist5)
	(on crate2 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)