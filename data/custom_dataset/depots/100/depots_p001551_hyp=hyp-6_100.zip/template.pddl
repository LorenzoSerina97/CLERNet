(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 distributor1)
	(on crate9 pallet0)
	(at pallet4 depot0)
	(at crate3 depot0)
	(clear crate0)
	(on crate5 pallet5)
	(on crate4 crate9)
	(at crate4 distributor1)
	(clear crate1)
	(clear crate6)
	(available hoist0)
	(clear crate5)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate6 crate3)
	(available hoist2)
	(at pallet2 depot0)
	(on crate7 pallet3)
	(on crate0 crate7)
	(at pallet3 distributor0)
	(clear crate4)
	(at crate1 depot0)
	(on crate1 pallet4)
	(at hoist1 depot0)
	(at crate5 distributor1)
	(at crate9 distributor1)
	(at crate0 distributor0)
	(at crate8 depot0)
	(at crate6 depot0)
	(at truck0 depot0)
	(at hoist0 distributor1)
	(at truck1 depot0)
	(at crate7 distributor0)
	(at pallet1 depot0)
	(at crate2 depot0)
	(on crate8 crate2)
	(on crate3 pallet1)
	(on crate2 pallet2)
	(clear crate8)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)