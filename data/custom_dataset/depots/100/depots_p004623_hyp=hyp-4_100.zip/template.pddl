(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		crate0 - Crate
		crate1 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
)
(:init

	(at truck1 depot1)
	(clear pallet3)
	(at hoist2 depot1)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(on crate0 pallet1)
	(available hoist1)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate0 depot0)
	(at pallet3 depot1)
	(available hoist3)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at hoist3 distributor0)
	(at pallet2 distributor1)
	(on crate1 pallet2)
	(at hoist0 distributor1)
	(clear pallet0)
	(at pallet1 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)