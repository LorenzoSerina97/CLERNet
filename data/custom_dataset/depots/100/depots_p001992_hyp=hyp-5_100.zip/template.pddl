(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate1 pallet3)
	(at pallet5 depot0)
	(on crate5 crate7)
	(on crate9 crate2)
	(clear crate0)
	(at crate7 distributor1)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(at hoist2 distributor1)
	(clear crate6)
	(clear crate5)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate0 crate4)
	(available hoist2)
	(on crate2 crate8)
	(at pallet3 distributor0)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(on crate8 pallet5)
	(at crate5 distributor1)
	(at crate6 distributor0)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(at hoist0 depot0)
	(on crate3 pallet0)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(at crate3 distributor1)
	(clear crate3)
	(clear crate9)
	(at crate0 distributor1)
	(at crate2 depot0)
	(on crate6 pallet1)
	(on crate7 pallet2)
	(at crate9 depot0)
	(on crate4 pallet4)
)
(:goal 
(and
<HYPOTHESIS>
))
)