(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate1 pallet3)
	(at pallet5 depot0)
	(on crate2 crate1)
	(at crate6 distributor1)
	(at crate7 distributor1)
	(on crate3 crate2)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate0 pallet1)
	(available hoist2)
	(at pallet0 distributor0)
	(at crate2 distributor1)
	(at crate0 depot0)
	(at crate1 distributor1)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate5 distributor1)
	(on crate6 pallet2)
	(clear pallet5)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(at crate3 distributor1)
	(clear pallet0)
	(on crate4 crate3)
	(at pallet1 depot0)
	(clear crate9)
	(on crate5 crate8)
	(on crate9 crate0)
	(on crate7 crate4)
	(at crate8 distributor1)
	(at pallet3 distributor1)
	(at crate9 depot0)
	(on crate8 pallet4)
)
(:goal 
(and
<HYPOTHESIS>
))
)