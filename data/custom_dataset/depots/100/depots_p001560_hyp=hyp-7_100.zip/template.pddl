(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate3 depot0)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(clear crate6)
	(at pallet4 distributor1)
	(at hoist2 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate3 crate7)
	(at crate8 distributor0)
	(available hoist2)
	(at crate0 depot0)
	(at pallet3 distributor0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(at pallet2 distributor1)
	(on crate8 pallet5)
	(at crate5 distributor1)
	(at crate6 distributor0)
	(at crate9 distributor1)
	(at crate4 distributor0)
	(on crate5 pallet4)
	(on crate1 pallet2)
	(on crate4 pallet3)
	(on crate7 pallet0)
	(at pallet1 depot0)
	(clear crate2)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate6 crate4)
	(on crate9 crate5)
	(clear crate8)
	(on crate0 crate3)
	(on crate2 pallet1)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)