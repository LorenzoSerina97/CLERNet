(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at truck0 depot2)
	(at pallet5 distributor1)
	(at pallet4 depot0)
	(at pallet1 depot2)
	(at hoist5 distributor1)
	(clear pallet2)
	(clear crate1)
	(available hoist0)
	(available hoist1)
	(available hoist2)
	(on crate2 crate0)
	(at pallet0 distributor0)
	(at pallet3 depot1)
	(available hoist3)
	(at hoist3 depot0)
	(at pallet2 distributor2)
	(at hoist2 distributor2)
	(available hoist4)
	(at crate2 depot1)
	(clear pallet5)
	(at truck1 distributor1)
	(on crate0 pallet3)
	(at truck2 depot0)
	(clear pallet0)
	(clear crate2)
	(at hoist4 depot1)
	(at hoist0 distributor0)
	(on crate1 pallet1)
	(at crate1 depot2)
	(at hoist1 depot2)
	(clear pallet4)
	(available hoist5)
	(at crate0 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)