(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate1 pallet3)
	(at truck1 depot1)
	(at pallet3 depot0)
	(clear pallet2)
	(clear crate0)
	(at truck2 depot1)
	(on crate0 pallet0)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at crate2 distributor1)
	(available hoist3)
	(at crate1 depot0)
	(at crate0 distributor2)
	(available hoist4)
	(at pallet2 depot2)
	(on crate2 pallet4)
	(clear pallet5)
	(at hoist4 distributor2)
	(at pallet0 distributor2)
	(at hoist3 depot1)
	(at hoist0 distributor1)
	(clear crate2)
	(at pallet1 depot1)
	(at hoist5 depot0)
	(at truck0 distributor1)
	(at hoist1 depot2)
	(available hoist5)
	(clear pallet1)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)