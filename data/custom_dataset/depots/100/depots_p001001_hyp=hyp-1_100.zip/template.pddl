(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(on crate1 crate2)
	(at pallet5 distributor1)
	(on crate9 pallet0)
	(at pallet4 depot0)
	(on crate3 pallet5)
	(clear pallet2)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(available hoist1)
	(available hoist2)
	(on crate2 crate5)
	(on crate7 crate3)
	(at pallet3 distributor0)
	(clear crate4)
	(at crate1 depot0)
	(clear crate7)
	(at crate6 distributor0)
	(at crate0 distributor0)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(at crate4 distributor0)
	(at crate5 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at truck0 depot0)
	(on crate0 pallet3)
	(at crate3 distributor1)
	(on crate6 crate0)
	(on crate4 crate6)
	(clear crate9)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate5 crate8)
	(at crate9 depot0)
	(clear pallet1)
	(at hoist2 distributor0)
	(on crate8 pallet4)
)
(:goal 
(and
<HYPOTHESIS>
))
)