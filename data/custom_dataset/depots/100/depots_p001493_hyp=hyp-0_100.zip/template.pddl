(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate2 crate4)
	(on crate5 pallet5)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(available hoist2)
	(on crate3 pallet3)
	(at crate4 depot0)
	(at pallet4 distributor0)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(at hoist1 depot0)
	(clear crate7)
	(at crate0 distributor0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(on crate1 crate9)
	(at crate5 depot0)
	(on crate0 pallet4)
	(at crate1 distributor0)
	(at crate3 distributor1)
	(at hoist0 distributor1)
	(clear crate3)
	(at crate7 distributor0)
	(on crate4 crate6)
	(clear crate2)
	(at crate2 depot0)
	(at pallet0 depot0)
	(on crate9 crate0)
	(clear crate8)
	(on crate6 pallet0)
	(at pallet3 distributor1)
	(at crate8 distributor1)
	(on crate7 pallet2)
	(at hoist2 distributor0)
	(on crate8 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)