(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate3 crate6)
	(at hoist1 distributor1)
	(at pallet5 depot0)
	(at pallet4 depot0)
	(clear pallet2)
	(at crate6 distributor1)
	(clear crate0)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet2 distributor0)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate9 crate8)
	(available hoist2)
	(clear crate4)
	(at crate1 depot0)
	(on crate8 pallet5)
	(on crate0 crate5)
	(at crate8 depot0)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(on crate1 crate9)
	(at hoist0 depot0)
	(at truck0 depot0)
	(on crate4 pallet3)
	(at crate3 distributor1)
	(on crate2 crate7)
	(clear crate3)
	(at truck1 depot0)
	(clear crate2)
	(at crate2 depot0)
	(on crate7 pallet4)
	(on crate5 pallet1)
	(on crate6 pallet0)
	(at pallet3 distributor1)
	(at crate9 depot0)
	(at hoist2 distributor0)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)