(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate1 pallet3)
	(at truck0 depot2)
	(at truck1 depot1)
	(at pallet5 distributor1)
	(at pallet4 depot0)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(at hoist2 distributor1)
	(at pallet2 distributor0)
	(at hoist5 depot1)
	(available hoist1)
	(available hoist2)
	(at truck2 distributor1)
	(at hoist3 distributor2)
	(at crate0 depot0)
	(at crate2 distributor0)
	(available hoist3)
	(available hoist4)
	(clear pallet5)
	(at pallet0 distributor2)
	(on crate0 pallet4)
	(at hoist1 distributor0)
	(at hoist4 depot0)
	(clear pallet0)
	(clear crate2)
	(at pallet1 depot1)
	(at crate1 depot2)
	(at pallet3 depot2)
	(on crate2 pallet2)
	(at hoist0 depot2)
	(available hoist5)
	(clear pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)