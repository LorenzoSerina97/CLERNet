(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate3 distributor0)
	(on crate4 pallet1)
	(on crate3 pallet5)
	(at crate7 distributor1)
	(on crate5 pallet0)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(at hoist2 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(on crate8 crate0)
	(at crate2 distributor1)
	(on crate6 pallet3)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(on crate1 crate6)
	(at pallet2 distributor1)
	(clear crate7)
	(on crate7 crate2)
	(at crate6 distributor0)
	(on crate2 pallet4)
	(at crate5 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(clear crate3)
	(at pallet1 depot0)
	(clear crate9)
	(at crate0 distributor1)
	(at pallet0 depot0)
	(on crate9 crate5)
	(on crate0 pallet2)
	(clear crate8)
	(at crate8 distributor1)
	(at crate9 depot0)
	(clear crate4)
)
(:goal 
(and
<HYPOTHESIS>
))
)