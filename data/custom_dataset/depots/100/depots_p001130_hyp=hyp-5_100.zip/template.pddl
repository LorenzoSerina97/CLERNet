(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate2 crate1)
	(at pallet5 depot0)
	(at pallet3 depot0)
	(at pallet4 depot0)
	(at crate3 depot0)
	(on crate3 pallet5)
	(clear crate0)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate9 crate8)
	(available hoist2)
	(at pallet0 distributor0)
	(on crate6 pallet3)
	(at crate0 depot0)
	(at crate2 distributor0)
	(at crate4 depot0)
	(at truck0 distributor0)
	(at pallet2 distributor1)
	(clear crate7)
	(at crate9 distributor1)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(on crate1 pallet0)
	(at crate5 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(on crate5 pallet4)
	(at hoist1 distributor0)
	(at crate1 distributor0)
	(on crate4 crate6)
	(clear crate2)
	(clear crate9)
	(on crate7 pallet2)
	(at crate8 distributor1)
	(on crate0 crate3)
	(clear crate4)
	(on crate8 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)