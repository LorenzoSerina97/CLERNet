(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate0 pallet5)
	(clear pallet3)
	(at hoist2 depot1)
	(clear crate0)
	(at truck2 depot1)
	(available hoist0)
	(clear crate1)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet0 depot2)
	(available hoist3)
	(at truck1 distributor0)
	(at hoist3 distributor1)
	(available hoist4)
	(at crate0 distributor0)
	(on crate2 pallet4)
	(at hoist4 distributor2)
	(at hoist0 depot0)
	(on crate1 pallet2)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(at pallet2 depot1)
	(clear pallet0)
	(at hoist5 depot2)
	(at pallet1 depot0)
	(clear crate2)
	(at crate2 distributor2)
	(at pallet4 distributor2)
	(at pallet3 distributor1)
	(available hoist5)
	(clear pallet1)
	(at crate1 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)