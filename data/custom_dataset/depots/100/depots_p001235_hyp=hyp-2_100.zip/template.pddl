(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at crate3 distributor0)
	(at pallet3 depot0)
	(at pallet4 depot0)
	(on crate4 crate1)
	(available hoist0)
	(clear crate6)
	(on crate9 pallet2)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate8 crate5)
	(available hoist2)
	(at pallet2 depot0)
	(at crate0 depot0)
	(on crate7 crate3)
	(at crate2 distributor0)
	(clear crate4)
	(at truck0 distributor0)
	(on crate1 pallet5)
	(at crate8 depot0)
	(at crate4 distributor0)
	(at pallet1 distributor0)
	(on crate5 pallet4)
	(at crate5 depot0)
	(at crate6 depot0)
	(at hoist0 depot0)
	(at truck1 distributor1)
	(at crate1 distributor0)
	(on crate0 pallet3)
	(on crate2 crate7)
	(on crate6 crate0)
	(clear pallet0)
	(at crate7 distributor0)
	(clear crate2)
	(clear crate9)
	(on crate3 pallet1)
	(clear crate8)
	(at crate9 depot0)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)