(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate4 pallet5)
	(on crate1 crate2)
	(at crate3 distributor0)
	(clear pallet3)
	(on crate0 pallet0)
	(clear crate1)
	(clear crate6)
	(available hoist0)
	(at pallet0 distributor1)
	(available hoist1)
	(at pallet5 distributor0)
	(on crate3 pallet4)
	(available hoist2)
	(at pallet2 depot0)
	(on crate2 crate5)
	(at pallet4 distributor0)
	(at crate1 depot0)
	(at hoist1 depot0)
	(clear crate7)
	(at crate9 distributor1)
	(at crate8 depot0)
	(at crate4 distributor0)
	(at crate6 depot0)
	(at crate5 depot0)
	(on crate5 pallet2)
	(at hoist0 distributor1)
	(on crate6 crate8)
	(clear crate3)
	(at truck1 depot0)
	(at crate7 distributor0)
	(at pallet1 depot0)
	(clear crate9)
	(at crate0 distributor1)
	(at crate2 depot0)
	(on crate9 crate0)
	(at truck0 distributor1)
	(on crate7 crate4)
	(at pallet3 distributor1)
	(at hoist2 distributor0)
	(on crate8 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)