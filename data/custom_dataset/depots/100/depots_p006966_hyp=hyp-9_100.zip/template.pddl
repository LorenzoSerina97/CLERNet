(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(at pallet3 depot0)
	(at truck0 depot1)
	(clear pallet2)
	(clear crate0)
	(at hoist1 distributor2)
	(clear crate1)
	(available hoist0)
	(at pallet4 distributor1)
	(on crate0 pallet1)
	(available hoist1)
	(available hoist2)
	(at truck2 distributor1)
	(available hoist3)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(on crate1 pallet4)
	(available hoist4)
	(at pallet2 depot2)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(clear pallet5)
	(at hoist4 depot2)
	(at pallet0 distributor2)
	(at pallet5 depot1)
	(at hoist3 depot1)
	(at hoist0 distributor1)
	(clear pallet0)
	(on crate2 pallet3)
	(clear crate2)
	(at crate2 depot0)
	(at hoist5 depot0)
	(available hoist5)
	(at hoist2 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)