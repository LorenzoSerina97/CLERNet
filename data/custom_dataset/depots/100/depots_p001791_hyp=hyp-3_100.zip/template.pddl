(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate4 pallet5)
	(at hoist1 distributor1)
	(at pallet5 distributor1)
	(at pallet4 depot0)
	(at crate3 depot0)
	(clear crate0)
	(at crate4 distributor1)
	(clear crate1)
	(available hoist0)
	(at crate8 distributor0)
	(at pallet2 distributor0)
	(available hoist1)
	(on crate7 pallet1)
	(on crate3 crate7)
	(on crate8 pallet2)
	(available hoist2)
	(on crate6 crate5)
	(at pallet0 distributor0)
	(at crate2 distributor0)
	(on crate1 crate6)
	(at crate6 distributor0)
	(on crate9 pallet4)
	(on crate2 pallet0)
	(on crate0 pallet3)
	(at crate1 distributor0)
	(clear crate3)
	(at truck1 depot0)
	(on crate5 crate2)
	(at pallet1 depot0)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate0 distributor1)
	(at hoist2 depot0)
	(at truck0 distributor1)
	(clear crate8)
	(at pallet3 distributor1)
	(at crate9 depot0)
	(clear crate4)
	(at crate5 distributor0)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)