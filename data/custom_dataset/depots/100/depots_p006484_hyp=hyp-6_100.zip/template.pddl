(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		depot2 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		distributor2 - Distributor
		truck0 - Truck
		truck1 - Truck
		truck2 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
		hoist3 - Hoist
		hoist4 - Hoist
		hoist5 - Hoist
)
(:init

	(on crate0 pallet5)
	(clear pallet3)
	(at hoist2 depot1)
	(clear pallet2)
	(clear crate0)
	(at truck2 depot1)
	(clear crate1)
	(available hoist0)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(available hoist3)
	(at truck0 distributor2)
	(at pallet2 distributor2)
	(available hoist4)
	(at crate0 distributor0)
	(at hoist4 distributor2)
	(on crate2 pallet0)
	(at hoist1 distributor0)
	(at hoist0 distributor1)
	(at truck1 depot0)
	(at hoist3 depot2)
	(clear crate2)
	(at crate2 depot0)
	(at pallet1 depot1)
	(at pallet0 depot0)
	(on crate1 pallet1)
	(at pallet4 depot2)
	(at hoist5 depot0)
	(clear pallet4)
	(at pallet3 distributor1)
	(available hoist5)
	(at crate1 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)