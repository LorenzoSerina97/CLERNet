(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(on crate5 crate7)
	(at crate3 depot0)
	(clear crate0)
	(at crate4 distributor1)
	(available hoist0)
	(clear crate6)
	(at pallet4 distributor1)
	(at crate8 distributor0)
	(at pallet0 distributor1)
	(available hoist1)
	(on crate3 pallet2)
	(on crate8 crate5)
	(available hoist2)
	(at pallet2 depot0)
	(at crate2 distributor1)
	(on crate9 pallet3)
	(on crate4 pallet0)
	(at pallet3 distributor0)
	(at crate1 depot0)
	(at truck0 distributor0)
	(at crate0 distributor0)
	(at crate9 distributor0)
	(clear pallet5)
	(at pallet1 distributor1)
	(at crate6 depot0)
	(on crate6 crate1)
	(at truck1 distributor1)
	(on crate0 crate8)
	(at hoist1 distributor0)
	(on crate1 crate3)
	(at hoist0 distributor1)
	(at crate7 distributor0)
	(clear crate2)
	(at hoist2 depot0)
	(clear pallet4)
	(on crate7 crate9)
	(clear crate4)
	(at crate5 distributor0)
	(on crate2 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)