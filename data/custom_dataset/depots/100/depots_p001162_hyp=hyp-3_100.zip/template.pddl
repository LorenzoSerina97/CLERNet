(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet4 depot0)
	(at crate3 depot0)
	(clear crate0)
	(available hoist0)
	(clear crate6)
	(available hoist1)
	(at pallet5 distributor0)
	(available hoist2)
	(at pallet2 depot0)
	(at crate0 depot0)
	(at crate2 distributor0)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(on crate4 pallet2)
	(at truck0 distributor0)
	(on crate9 crate7)
	(on crate0 crate5)
	(at crate6 distributor0)
	(at crate8 depot0)
	(at crate9 distributor0)
	(at pallet1 distributor1)
	(on crate1 crate9)
	(at crate5 depot0)
	(on crate6 crate1)
	(at truck1 distributor1)
	(on crate5 crate3)
	(on crate3 pallet0)
	(at crate1 distributor0)
	(at crate7 distributor0)
	(on crate2 pallet3)
	(clear crate2)
	(at hoist0 distributor0)
	(at pallet0 depot0)
	(on crate7 pallet5)
	(at hoist2 depot0)
	(clear crate8)
	(clear pallet1)
	(clear crate4)
	(on crate8 pallet4)
)
(:goal 
(and
<HYPOTHESIS>
))
)