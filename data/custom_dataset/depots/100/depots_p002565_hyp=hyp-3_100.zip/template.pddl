(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet0 depot1)
	(at truck0 depot1)
	(at crate3 depot0)
	(clear crate0)
	(available hoist0)
	(clear crate1)
	(on crate3 pallet2)
	(available hoist1)
	(at hoist0 depot1)
	(at pallet2 depot0)
	(available hoist2)
	(on crate2 crate5)
	(at crate2 distributor0)
	(at crate4 depot0)
	(on crate0 crate2)
	(at truck1 distributor0)
	(at crate0 distributor0)
	(at pallet1 distributor0)
	(on crate1 pallet0)
	(at hoist1 distributor0)
	(on crate4 crate3)
	(at hoist2 depot0)
	(on crate5 pallet1)
	(clear crate4)
	(at crate1 depot1)
	(at crate5 distributor0)
)
(:goal 
(and
<HYPOTHESIS>
))
)