(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 distributor1)
	(on crate0 pallet5)
	(on crate2 crate6)
	(clear pallet3)
	(on crate4 pallet1)
	(at crate3 depot0)
	(at crate6 distributor1)
	(at crate7 distributor1)
	(available hoist0)
	(clear crate1)
	(at pallet4 distributor1)
	(clear crate5)
	(available hoist1)
	(on crate3 crate4)
	(available hoist2)
	(at crate2 distributor1)
	(on crate8 pallet0)
	(at crate4 depot0)
	(at pallet3 distributor0)
	(at truck1 distributor0)
	(at crate1 distributor1)
	(at pallet2 distributor1)
	(at crate9 distributor1)
	(on crate9 pallet4)
	(at crate8 depot0)
	(on crate6 pallet2)
	(at crate5 depot0)
	(at truck0 depot0)
	(clear crate3)
	(at pallet1 depot0)
	(clear crate2)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate0 distributor1)
	(at pallet0 depot0)
	(on crate7 crate0)
	(at hoist2 depot0)
	(on crate5 crate8)
	(on crate1 crate7)
)
(:goal 
(and
<HYPOTHESIS>
))
)