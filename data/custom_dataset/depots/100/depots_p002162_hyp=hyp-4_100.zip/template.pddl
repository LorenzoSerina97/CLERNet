(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(on crate2 crate1)
	(at truck1 depot1)
	(at hoist2 depot1)
	(at truck0 depot1)
	(at crate3 depot0)
	(clear pallet2)
	(on crate5 pallet0)
	(available hoist0)
	(available hoist1)
	(on crate3 crate4)
	(available hoist2)
	(at crate0 depot0)
	(at crate4 depot0)
	(at crate2 distributor0)
	(on crate4 crate0)
	(on crate0 crate5)
	(at pallet1 distributor0)
	(at crate5 depot0)
	(at hoist0 depot0)
	(at crate1 distributor0)
	(at hoist1 distributor0)
	(at pallet2 depot1)
	(clear crate3)
	(clear crate2)
	(on crate1 pallet1)
	(at pallet0 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)