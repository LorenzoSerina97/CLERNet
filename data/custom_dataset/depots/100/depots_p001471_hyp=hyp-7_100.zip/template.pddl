(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at hoist1 distributor1)
	(at pallet5 distributor1)
	(clear crate0)
	(at crate7 distributor1)
	(on crate0 pallet0)
	(at crate4 distributor1)
	(available hoist0)
	(at pallet4 distributor1)
	(clear crate5)
	(available hoist1)
	(on crate3 pallet4)
	(available hoist2)
	(at pallet2 depot0)
	(on crate8 crate1)
	(at crate0 depot0)
	(at crate2 distributor0)
	(at pallet3 distributor0)
	(clear crate4)
	(at truck1 distributor0)
	(at crate1 depot0)
	(on crate1 crate6)
	(at truck0 distributor0)
	(on crate9 pallet5)
	(clear crate7)
	(at crate9 distributor1)
	(at crate8 depot0)
	(at pallet1 distributor0)
	(on crate6 pallet2)
	(at crate6 depot0)
	(at hoist0 depot0)
	(at crate3 distributor1)
	(on crate4 crate3)
	(clear crate2)
	(at pallet0 depot0)
	(on crate5 pallet3)
	(clear crate8)
	(on crate7 crate9)
	(at hoist2 distributor0)
	(at crate5 distributor0)
	(on crate2 pallet1)
)
(:goal 
(and
<HYPOTHESIS>
))
)