(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at crate3 depot0)
	(at hoist1 depot1)
	(on crate0 pallet0)
	(on crate3 crate2)
	(available hoist0)
	(clear crate1)
	(available hoist1)
	(available hoist2)
	(at pallet2 depot0)
	(at pallet0 distributor0)
	(clear crate4)
	(at truck1 distributor0)
	(at truck0 distributor0)
	(on crate4 crate0)
	(at crate0 distributor0)
	(at crate4 distributor0)
	(at hoist0 depot0)
	(at crate5 depot1)
	(clear crate3)
	(on crate1 crate5)
	(at crate2 depot0)
	(at pallet1 depot1)
	(on crate2 pallet2)
	(on crate5 pallet1)
	(at hoist2 distributor0)
	(at crate1 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)