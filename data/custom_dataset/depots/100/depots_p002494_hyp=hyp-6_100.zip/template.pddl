(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at truck1 depot1)
	(on crate4 pallet1)
	(at crate3 depot0)
	(on crate2 crate4)
	(at hoist1 depot1)
	(on crate0 pallet0)
	(at crate4 depot1)
	(available hoist0)
	(clear crate1)
	(clear crate5)
	(on crate3 pallet2)
	(available hoist1)
	(on crate1 crate0)
	(available hoist2)
	(at pallet2 depot0)
	(at pallet0 distributor0)
	(at crate0 distributor0)
	(at crate2 depot1)
	(at crate5 depot1)
	(at truck0 depot0)
	(at crate1 distributor0)
	(clear crate3)
	(on crate5 crate2)
	(at hoist0 distributor0)
	(at pallet1 depot1)
	(at hoist2 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)