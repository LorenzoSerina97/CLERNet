(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		depot1 - Depot
		distributor0 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(clear crate0)
	(at crate4 depot1)
	(available hoist0)
	(clear crate5)
	(at pallet2 distributor0)
	(available hoist1)
	(at crate3 depot1)
	(available hoist2)
	(at hoist0 depot1)
	(at truck1 distributor0)
	(at crate0 distributor0)
	(on crate2 pallet0)
	(at crate5 depot0)
	(at truck0 depot0)
	(at hoist1 distributor0)
	(on crate4 crate3)
	(on crate5 crate2)
	(on crate1 pallet1)
	(at pallet1 depot1)
	(at pallet0 depot0)
	(at crate2 depot0)
	(at hoist2 depot0)
	(on crate0 pallet2)
	(on crate3 crate1)
	(clear crate4)
	(at crate1 depot1)
)
(:goal 
(and
<HYPOTHESIS>
))
)