(define (problem depots-test)
(:domain depots)
(:objects
		depot0 - Depot
		distributor0 - Distributor
		distributor1 - Distributor
		truck0 - Truck
		truck1 - Truck
		pallet0 - Pallet
		pallet1 - Pallet
		pallet2 - Pallet
		pallet3 - Pallet
		pallet4 - Pallet
		pallet5 - Pallet
		crate0 - Crate
		crate1 - Crate
		crate2 - Crate
		crate3 - Crate
		crate4 - Crate
		crate5 - Crate
		crate6 - Crate
		crate7 - Crate
		crate8 - Crate
		crate9 - Crate
		hoist0 - Hoist
		hoist1 - Hoist
		hoist2 - Hoist
)
(:init

	(at pallet5 depot0)
	(at crate3 distributor0)
	(at crate6 distributor1)
	(on crate9 crate4)
	(available hoist0)
	(clear crate5)
	(at hoist2 distributor1)
	(available hoist1)
	(on crate3 pallet4)
	(available hoist2)
	(at pallet2 depot0)
	(at pallet0 distributor0)
	(on crate8 crate1)
	(on crate6 pallet3)
	(at pallet4 distributor0)
	(at crate1 depot0)
	(at hoist1 depot0)
	(clear crate7)
	(at crate5 distributor1)
	(at crate8 depot0)
	(at crate4 distributor0)
	(on crate0 crate6)
	(at crate9 distributor0)
	(clear pallet0)
	(at truck1 depot0)
	(on crate4 crate3)
	(at pallet1 depot0)
	(clear crate2)
	(clear crate9)
	(at hoist0 distributor0)
	(at crate2 depot0)
	(on crate1 pallet1)
	(at crate0 distributor1)
	(at truck0 distributor1)
	(clear crate8)
	(on crate5 crate0)
	(at pallet3 distributor1)
	(on crate7 pallet2)
	(on crate2 pallet5)
	(at crate7 depot0)
)
(:goal 
(and
<HYPOTHESIS>
))
)